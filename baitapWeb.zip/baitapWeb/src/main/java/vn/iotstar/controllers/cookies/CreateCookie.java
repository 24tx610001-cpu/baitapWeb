package vn.iotstar.controllers.cookies;

import jakarta.servlet.http.HttpServlet;

public class CreateCookie extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	

}
