package vn.iotstar.utils;

public class Constant {
    // Quan trọng: Thay đổi đường dẫn này cho phù hợp với máy Mac của bạn
    public static final String DIR = "/Users/tobi/uploads"; 
}